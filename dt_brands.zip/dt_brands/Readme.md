# Brands on FO

## About

Adds a block containing the customer\'s shopping cart.

## Usage

Download the file, take the .zip and install it on your store.

## Contributing

I don't have any requirements for the PR, but you can make however you think is appropiate

## License

This software is licensed under MIT License, check the license file.